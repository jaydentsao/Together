# Together
Adam, Jayden, and Andy's HCS3 final game

Together: A multiplayer scrolling platformer over the network. Play with friends in a collaborative and chaotic environment to complete levels!

Known bugs:
  Players will sometimes snap up or down too many pixels when hitting a wall
